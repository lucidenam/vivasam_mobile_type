
-- 회원 정보 테이블 컬럼 추가. 가입한 곳
alter table MEMBER add VIA VARCHAR(20);

exec sp_addextendedproperty 'MS_Description', '가입 출처. MOBILE, WEB', 'SCHEMA', 'dbo', 'TABLE', 'MEMBER', 'COLUMN', 'VIA'
go

UPDATE MEMBER SET VIA = 'WEB' WHERE VIA IS NULL;

-- 비바 샘터의 추천 수업 자료 배너 정보
create table RECO_EDU_MATERIAL_BANNER
(
  ID               int identity constraint PK_RECO_EDU_MATERIAL primary key,
  BANNER_NAME      nvarchar(50),
  LINK_TYPE        varchar(10),
  BANNER_URL       varchar(500),
  BANNER_FILE_ORG  nvarchar(200),
  BANNER_FILE_SAV  nvarchar(200),
  BANNER_FILE_PATH nvarchar(200),
  BANNER_REGDATE   datetime constraint DF_RECO_EDU_MATERIAL_BANNER_REGDATE default getdate(),
  BANNER_REGID     varchar(50),
  BANNER_MODDATE   datetime constraint DF_RECO_EDU_MATERIAL_BANNER_MODDATE default getdate(),
  BANNER_MODID     varchar(50),
  BANNER_USE_YN    char(1) constraint DF_RECO_EDU_MATERIAL_BANNER_USE_YN default 'Y',
)
go

exec sp_addextendedproperty 'MS_Description', '비바샘터 추천 수업 자료 배너 정보', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER'
go

exec sp_addextendedproperty 'MS_Description', '배너 이름', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_NAME'
go

  exec sp_addextendedproperty 'MS_Description', '링크 유형. CURRENT or NEW', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'LINK_TYPE'
go

exec sp_addextendedproperty 'MS_Description', '배너 클릭 시 이동할 URL', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_URL'
go

exec sp_addextendedproperty 'MS_Description', '업로드한 배너 이미지 원본 파일 명', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_FILE_ORG'
go

exec sp_addextendedproperty 'MS_Description', '업로드한 배너 이미지 저장 이름. 한글인 경우 ASCII 스타일로 변경', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_FILE_SAV'
go

exec sp_addextendedproperty 'MS_Description', '업로드한 배너를 저장하는 경로', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_FILE_PATH'
go

exec sp_addextendedproperty 'MS_Description', '배너 등록 일시', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_REGDATE'
go

exec sp_addextendedproperty 'MS_Description', '배너를 등록한 사용자의 아이디', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_REGID'
go

exec sp_addextendedproperty 'MS_Description', '배너 정보 수정 일시', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_MODDATE'
go

exec sp_addextendedproperty 'MS_Description', '배너 정보를 수정한 사용자의 아이디', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_MODID'
go

exec sp_addextendedproperty 'MS_Description', '공개 여부. Y or N', 'SCHEMA', 'dbo', 'TABLE', 'RECO_EDU_MATERIAL_BANNER', 'COLUMN', 'BANNER_USE_YN'
go


-- 푸시 메시지 용 토큰 정보 테이블
create table DEVICE_APP_TOKENS
(
  ID int identity constraint PK_DEVICE_APP_TOKENS primary key,
  TOKEN varchar(200) not null,
  MEMBER_ID varchar(30),
  OS varchar(100),
  REGDATE   datetime constraint DF_DEVICE_APP_TOKENS_REGDATE default getdate(),
  MODDATE   datetime constraint DF_DEVICE_APP_TOKENS_MODDATE default getdate()
)
go

create unique index UQ_DEVICE_APP_TOKENS_TOKEN
on DEVICE_APP_TOKENS (TOKEN)
go

exec sp_addextendedproperty 'MS_Description', '앱 사용자들의 푸시 메시지 전송을 위한 Token', 'SCHEMA', 'dbo', 'TABLE', 'DEVICE_APP_TOKENS'
go

exec sp_addextendedproperty 'MS_Description', 'Firebase App Token. Device 에서 전송하는 값.', 'SCHEMA', 'dbo', 'TABLE', 'DEVICE_APP_TOKENS', 'COLUMN', 'TOKEN'
go

exec sp_addextendedproperty 'MS_Description', '비바샘 회원 아이디. 로그인 하지 않고도 푸시 메시지를 받을 수 있으므로 이 값은 NULL 허용. 한 사용자 ID 는 여러 Token 을 가질 수 있음 (여러 디바이스를 가질 수 있으므로)', 'SCHEMA', 'dbo', 'TABLE', 'DEVICE_APP_TOKENS', 'COLUMN', 'MEMBER_ID'
go

exec sp_addextendedproperty 'MS_Description', 'iOS or Android', 'SCHEMA', 'dbo', 'TABLE', 'DEVICE_APP_TOKENS', 'COLUMN', 'OS'
go




-- 이벤트
alter table EVENT_INFO add EVENT_TARGET_PLATFORM VARCHAR(20);
ALTER TABLE EVENT_INFO ADD EVENT_MOB_BN_ORG NVARCHAR(200) NULL;
ALTER TABLE EVENT_INFO ADD EVENT_MOB_BN_SAV nvarchar(200) NULL;
ALTER TABLE EVENT_INFO ADD EVENT_MOB_BN_PATH nvarchar(200) NULL;
ALTER TABLE EVENT_INFO ADD MOBILE_APPLY_CONTENTS ntext NULL;
ALTER TABLE EVENT_INFO ADD MOBILE_THUM_PATH_URL nvarchar(300) NULL;
ALTER TABLE EVENT_INFO ADD MOBILE_TERM ntext NULL;


exec sp_addextendedproperty 'MS_Description', '대상 플랫폼. ALL or WEB or MOBILE', 'SCHEMA', 'dbo', 'TABLE', 'EVENT_INFO', 'COLUMN', 'EVENT_TARGET_PLATFORM'
go

exec sp_addextendedproperty 'MS_Description', '이벤트 모바일 배너 원본이미지명', 'SCHEMA', 'dbo', 'TABLE', 'EVENT_INFO', 'COLUMN', 'EVENT_MOB_BN_ORG'
go

exec sp_addextendedproperty 'MS_Description', '이벤트 모바일 배너 저장이미지명', 'SCHEMA', 'dbo', 'TABLE', 'EVENT_INFO', 'COLUMN', 'EVENT_MOB_BN_SAV'
go

exec sp_addextendedproperty 'MS_Description', '이벤트 모바일 배너', 'SCHEMA', 'dbo', 'TABLE', 'EVENT_INFO', 'COLUMN', 'EVENT_MOB_BN_PATH'
go

exec sp_addextendedproperty 'MS_Description', '모바일 신청페이지 상세내용', 'SCHEMA', 'dbo', 'TABLE', 'EVENT_INFO', 'COLUMN', 'MOBILE_APPLY_CONTENTS'
go

exec sp_addextendedproperty 'MS_Description', '모바일 약관', 'SCHEMA', 'dbo', 'TABLE', 'EVENT_INFO', 'COLUMN', 'MOBILE_TERM'
go

UPDATE EVENT_INFO SET EVENT_TARGET_PLATFORM = 'WEB' WHERE EVENT_TARGET_PLATFORM IS NULL;




-- 이벤트 신청
alter table EVENT_JOIN add VIA VARCHAR(20);

exec sp_addextendedproperty 'MS_Description', '이벤트 참여한 곳. WEB or MOBILE', 'SCHEMA', 'dbo', 'TABLE', 'EVENT_JOIN', 'COLUMN', 'VIA'
go

UPDATE EVENT_JOIN SET via = 'WEB' WHERE via IS NULL;



-- 교사문화 프로그램 / 오프라인 세미나
ALTER TABLE CULTURE_ACT_INFO ADD TARGET_PLATFORM VARCHAR(20);
ALTER TABLE CULTURE_ACT_INFO ADD MOBILE_THUM_PATH_URL NVARCHAR(300) NULL;
ALTER TABLE CULTURE_ACT_INFO ADD MOBILE_CONTENTS ntext NULL;
ALTER TABLE CULTURE_ACT_INFO ADD MOBILE_APPLY_CONTENTS ntext NULL;
ALTER TABLE CULTURE_ACT_INFO ADD MOBILE_TERM ntext NULL;

--CULTURE_ACT_INFO 테이블에
--밑에 2개 컬럼도 추가 부탁드립니다. 타입은 개발DB 확인 부탁드려요
ADD_CHECKBOX_YN  (추가 동의 YN)
ADD_CHECKBOX_TEXT (추가 동의 내용)
------------------

exec sp_addextendedproperty 'MS_Description', '대상 플랫폼. ALL or WEB or MOBILE', 'SCHEMA', 'dbo', 'TABLE', 'CULTURE_ACT_INFO', 'COLUMN', 'TARGET_PLATFORM'
go

exec sp_addextendedproperty 'MS_Description', '모바일 썸네일 경로URL', 'SCHEMA', 'dbo', 'TABLE', 'CULTURE_ACT_INFO', 'COLUMN', 'MOBILE_THUM_PATH_URL'
go

exec sp_addextendedproperty 'MS_Description', '모바일 내용', 'SCHEMA', 'dbo', 'TABLE', 'CULTURE_ACT_INFO', 'COLUMN', 'MOBILE_CONTENTS'
go

exec sp_addextendedproperty 'MS_Description', '모바일 신청페이지 상세내용', 'SCHEMA', 'dbo', 'TABLE', 'CULTURE_ACT_INFO', 'COLUMN', 'MOBILE_APPLY_CONTENTS'
go

exec sp_addextendedproperty 'MS_Description', '모바일 약관', 'SCHEMA', 'dbo', 'TABLE', 'CULTURE_ACT_INFO', 'COLUMN', 'MOBILE_TERM'
go

UPDATE CULTURE_ACT_INFO SET TARGET_PLATFORM = 'WEB' WHERE TARGET_PLATFORM IS NULL;




-- 교사문화 프로그램 / 오프라인 세미나 신청
ALTER TABLE CULTURE_ACT_APPLY_INFO ADD VIA VARCHAR(20);

exec sp_addextendedproperty 'MS_Description', '교사문화 프로그램, 오프라인 세미나 참여한 곳. WEB or MOBILE', 'SCHEMA', 'dbo', 'TABLE', 'CULTURE_ACT_APPLY_INFO', 'COLUMN', 'VIA'
go

UPDATE CULTURE_ACT_APPLY_INFO SET via = 'WEB' WHERE via IS NULL;



-- 설문조사
ALTER TABLE SURVEY_INFO ADD TARGET_PLATFORM VARCHAR(20);

exec sp_addextendedproperty 'MS_Description', '대상 플랫폼. ALL or WEB or MOBILE', 'SCHEMA', 'dbo', 'TABLE', 'SURVEY_INFO', 'COLUMN', 'TARGET_PLATFORM'
go

UPDATE SURVEY_INFO SET TARGET_PLATFORM = 'WEB' WHERE TARGET_PLATFORM IS NULL;




-- 설문조사 신청
ALTER TABLE SURVEY_APPLY_INFO ADD VIA VARCHAR(20);

exec sp_addextendedproperty 'MS_Description', '설문조사 참여한 곳. WEB or MOBILE', 'SCHEMA', 'dbo', 'TABLE', 'SURVEY_APPLY_INFO', 'COLUMN', 'VIA'
go

UPDATE SURVEY_APPLY_INFO SET via = 'WEB' WHERE via IS NULL;

-- 공지사항
ALTER TABLE NOTICE_INFO ADD MOBILE_DISPLAY_YN CHAR(1);

exec sp_addextendedproperty 'MS_Description', '모바일 노출 여부. Y or N', 'SCHEMA', 'dbo', 'TABLE', 'NOTICE_INFO', 'COLUMN', 'MOBILE_DISPLAY_YN'
go